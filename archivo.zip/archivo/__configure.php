<?php
// zwraca ścieżkę do pliku C:/xampp/htdocs/licenciat_fiszki-main
define("ROOT_PATH", str_replace('\\', "/", dirname(__FILE__)));
