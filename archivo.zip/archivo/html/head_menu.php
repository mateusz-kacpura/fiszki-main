
<div class="select" >

<button  class="fiszki przycisk przycisk1" id="przycisk">NAUKA</button>
<button  class="zestawy przycisk przycisk1" id="zestawy">ZARZĄDZAJ ZESTAWAMI</button>

</div>