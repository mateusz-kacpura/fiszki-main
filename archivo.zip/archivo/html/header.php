    <head>
        <meta charset="UTF-8">
        <title>Document</title>
        <link rel="stylesheet" href="././css/css/fontello.css">
        <link rel="stylesheet" href="././css/style.css">
        <link rel="stylesheet" href="././css/cms.css">
        <link href="../css/css/style.scss" rel="stylesheet/scss" type="text/css">
        <script src="jquery.min.js"></script>

    </head>

    
