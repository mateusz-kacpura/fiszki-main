<!DOCTYPE html>
<html lang="en">
<?php include('html/header.php') ?>

<body>
   <form action="php/panel_login/login_deflaut.php" method="post" class="login">
        <fieldset><legend>LOGIN DO BAZY Z FISZKAMI</legend><input type="text" name="login"></fieldset>
        <fieldset><legend>HASŁO DO BAZY Z FISZKAMI</legend><input type="password" name="password"></fieldset><br>
        <input type="submit" value="ZALOGUJ">
   </form>
</body>
</html>

