
<script src="js/panel_admin/choose_table/click_connections.js"></script>
<script src="js/panel_admin/choose_table/scripts.js"></script>
<script src="js/panel_admin/inside_table/action_click_menu_button.js"></script>

