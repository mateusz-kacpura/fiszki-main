<?php

require_once "__navigate_table.php";
require_once "select_table_by_flag.php";
require_once "dodaj_zestaw.php";
require_once "usun_zestaw.php";
require_once "wyszukaj_zestaw.php";
require_once "importuj_baze_danych.php";

?>