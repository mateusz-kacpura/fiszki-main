<?php

function html_wyloguj(){
    echo'<div>
                    <a href="table_settings/log_out.php">WYLOGUJ</a>
         </div>';
}

