<?php
$angielski = 'v1';
$polski = 'v2';
$przyklad = 'weight';
$zdanie = 'zdanie';
$flaga_baza = 'flaga';
?>