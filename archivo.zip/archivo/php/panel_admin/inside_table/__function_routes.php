<?php
require_once "active_table.php"; //wywala błąd w lini 15 niezdefiniowana zmienna $table
require_once "__navigate_inside_table.php";
require_once "add_form.php";
require_once "add_menu_right.php";
require_once "add_word.php";
require_once "buttons_activate_table.php";
// require_once "deactivate_the_word_table.php"; //wywala błąd w lini 6 niezdefiniowana zmienna $table
require_once "deactive_table.php";
require_once "delete_table_word.php";
require_once "delete_table.php";
require_once "edit_flag.php";
require_once "edit_table_row.php";
require_once "filter.php";
require_once "load_add_word.php";
require_once "load_fishcards_all.php";
// require_once "load_table_words.php"; plik powoduje wywolonaie echo na topie strony
require_once "load_table_name.php";
require_once "load_word_by_id.php";
require_once "search_table_word.php";
?>