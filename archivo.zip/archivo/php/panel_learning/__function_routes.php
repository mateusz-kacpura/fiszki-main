<?php
require_once "load_table_fishcards.php";
?>