<div class="menu">
        <div class="menubutton"></div>
        <div class="menu-content"> 
            <div>
                <h1>TRYBY</h1>
                
            </div>
        </div>
    </div>